package com.melognator.clinicaodontologica.service;

import com.melognator.clinicaodontologica.entity.Odontologo;
import com.melognator.clinicaodontologica.entity.Paciente;
import com.melognator.clinicaodontologica.entity.Turno;
import com.melognator.clinicaodontologica.repository.TurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class ServiceTurno {

    private final TurnoRepository repository;

    @Autowired
    public ServiceTurno(TurnoRepository repository) {
        this.repository = repository;
    }

    public Turno guardar(Turno turno) {
        return repository.save(turno);
    }
    public void actualizar(Turno turno) {
        repository.save(turno);
    }
    public void eliminar(Long id) {
        repository.deleteById(id);
    }
    public Optional<Turno> buscar(Long id) {return repository.findById(id);}
    public Optional<Set<Turno>> buscarPorOdontologo(Odontologo odontologo) {return repository.findByOdontologo(odontologo);}
    public Optional<Set<Turno>> buscarPorPaciente(Paciente paciente) {return repository.findByPaciente(paciente);}

    public List<Turno> buscarTodo() {
        return repository.findAll();
    }
}
