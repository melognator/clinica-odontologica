//package com.melognator.clinicaodontologica.service;
//
//import com.melognator.clinicaodontologica.repository.DomicilioRepository;
//import com.melognator.clinicaodontologica.entity.Domicilio;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class ServiceDomicilio {
//
//    private final DomicilioRepository repository;
//
//    @Autowired
//    public ServiceDomicilio(DomicilioRepository repository) {
//        this.repository = repository;
//    }
//
//    public Domicilio guardar(Domicilio domicilio) {
//        return repository.save(domicilio);
//    }
//    public void actualizar(Domicilio domicilio) {
//        repository.save(domicilio);
//    }
//    public void eliminar(Long id) {
//        repository.deleteById(id);
//    }
//    public Optional<Domicilio> buscar(Long id) {
//        return repository.findById(id);
//    }
//    public List<Domicilio> buscarTodo() {
//        return repository.findAll();
//    }
//
//}
