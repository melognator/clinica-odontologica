package com.melognator.clinicaodontologica.service;

import com.melognator.clinicaodontologica.repository.PacienteRepository;
import com.melognator.clinicaodontologica.entity.Paciente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicePaciente {
    private final PacienteRepository repository;

    @Autowired
    public ServicePaciente(PacienteRepository repository) {
        this.repository = repository;
    }

    public Paciente guardar(Paciente paciente) {
        return repository.save(paciente);
    }
    public void actualizar(Paciente paciente) {
        repository.save(paciente);
    }
    public void eliminar(Long id) {
        repository.deleteById(id);
    }
    public Optional<Paciente> buscar(Long id) {
        return repository.findById(id);
    }
    public Paciente buscarPorEmail(String email) {
        return null;
    }
    public List<Paciente> buscarTodo() {
        return repository.findAll();
    }
}
