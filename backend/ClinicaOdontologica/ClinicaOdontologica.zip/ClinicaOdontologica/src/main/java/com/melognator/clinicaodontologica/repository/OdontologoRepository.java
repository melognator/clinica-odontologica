package com.melognator.clinicaodontologica.repository;

import com.melognator.clinicaodontologica.entity.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OdontologoRepository extends JpaRepository<Odontologo, Long> {}
