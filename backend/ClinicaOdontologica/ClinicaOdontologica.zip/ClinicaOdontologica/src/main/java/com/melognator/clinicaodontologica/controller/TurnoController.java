package com.melognator.clinicaodontologica.controller;

import com.melognator.clinicaodontologica.entity.Odontologo;
import com.melognator.clinicaodontologica.entity.Paciente;
import com.melognator.clinicaodontologica.entity.Turno;
import com.melognator.clinicaodontologica.service.ServiceOdontologo;
import com.melognator.clinicaodontologica.service.ServicePaciente;
import com.melognator.clinicaodontologica.service.ServiceTurno;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/api/turnos")
@CrossOrigin("*")
public class TurnoController {
    private final ServiceTurno serviceTurno;
    private final ServiceOdontologo serviceOdontologo;
    private final ServicePaciente servicePaciente;
    @Autowired
    public TurnoController(ServiceTurno serviceTurno, ServicePaciente servicePaciente, ServiceOdontologo serviceOdontologo) {
        this.serviceTurno = serviceTurno;
        this.servicePaciente = servicePaciente;
        this.serviceOdontologo = serviceOdontologo;
    }

    @GetMapping
    public ResponseEntity<List<Turno>> listarLosTurnos(){
        return ResponseEntity.ok(serviceTurno.buscarTodo());
    }
    @PostMapping
    public ResponseEntity<Turno> registarTurno(@RequestBody Turno turno){
        Optional<Paciente> pacienteBuscado = servicePaciente.buscar(turno.getPaciente().getId());
        Optional<Odontologo> odontologoBuscado = serviceOdontologo.buscar(turno.getOdontologo().getId());
        if (pacienteBuscado.isPresent() && odontologoBuscado.isPresent()){
            turno.setPaciente(pacienteBuscado.get());
            turno.setOdontologo(odontologoBuscado.get());
            return ResponseEntity.ok(serviceTurno.guardar(turno));
        }
        return ResponseEntity.badRequest().build();
    }

    @GetMapping("/buscar-odontologo/{id}")
    public ResponseEntity<Set<Turno>> buscarPorOdontologo(@PathVariable Long id) {
        Optional<Odontologo> odontologoBuscado = serviceOdontologo.buscar(id);
        if(odontologoBuscado.isPresent()) {
            Optional<Set<Turno>> turnos = serviceTurno.buscarPorOdontologo(odontologoBuscado.get());
            if (turnos.isPresent()) {
                return ResponseEntity.ok(turnos.get());
            }
        }
        return ResponseEntity.badRequest().build();
    }

    @GetMapping("/buscar-paciente/{id}")
    public ResponseEntity<Set<Turno>> buscarPorPaciente(@PathVariable Long id) {
        Optional<Paciente> pacienteBuscado = servicePaciente.buscar(id);
        if(pacienteBuscado.isPresent()) {
            Optional<Set<Turno>> turnos = serviceTurno.buscarPorPaciente(pacienteBuscado.get());
            if (turnos.isPresent()) {
                return ResponseEntity.ok(turnos.get());
            }
        }
        return ResponseEntity.badRequest().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Turno> buscarPorId(@PathVariable Long id) {
        Optional<Turno> turnoBuscado = serviceTurno.buscar(id);
        if (turnoBuscado.isPresent()) {
            return ResponseEntity.ok(turnoBuscado.get());
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> eliminarTurno(@PathVariable Long id) {
        Optional<Turno> turnoBuscado = serviceTurno.buscar(id);
        if (turnoBuscado.isPresent()) {
            serviceTurno.eliminar(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
    @PutMapping
    public ResponseEntity<Object> actualizarTurno(@RequestBody Turno turno) {
        Optional<Turno> turnoBuscado = serviceTurno.buscar(turno.getId());
        if (turnoBuscado.isPresent()) {
            serviceTurno.actualizar(turno);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
}

