package com.melognator.clinicaodontologica.controller;

import com.melognator.clinicaodontologica.entity.Odontologo;
import com.melognator.clinicaodontologica.entity.Turno;
import com.melognator.clinicaodontologica.service.ServiceOdontologo;
import com.melognator.clinicaodontologica.service.ServiceTurno;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/api/odontologos")
@CrossOrigin("*")
public class OdontologoController {

    @Autowired
    private final ServiceOdontologo serviceOdontologo;
    private final ServiceTurno serviceTurno;
    public OdontologoController(ServiceOdontologo serviceOdontologo, ServiceTurno serviceTurno) {
        this.serviceOdontologo = serviceOdontologo;
        this.serviceTurno = serviceTurno;
    }

    @GetMapping
    public ResponseEntity<List<Odontologo>> getOdontologos() {
        List<Odontologo> odontologos = serviceOdontologo.buscarTodo();
        return ResponseEntity.ok(odontologos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Odontologo> buscarPorId(@PathVariable Long id) {
        Optional<Odontologo> odontologoBuscado = serviceOdontologo.buscar(id);
        if (odontologoBuscado.isPresent()) {
            return ResponseEntity.ok(odontologoBuscado.get());
//            return ResponseEntity.badRequest().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Odontologo> crearOdontologo(@RequestBody Odontologo odontologo) {
        Odontologo odontologoCreado = serviceOdontologo.guardar(odontologo);
        if (odontologoCreado.getId() != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(odontologoCreado);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> eliminarOdontologo(@PathVariable("id") Long id) {
//        Odontologo odontologoBuscado = serviceOdontologo.buscar(id);
//        if (odontologoBuscado != null) {
//            serviceOdontologo.eliminar(id);
//            return ResponseEntity.ok().build();
//        } else {
//            return ResponseEntity.notFound().build();
//        }
        serviceOdontologo.eliminar(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping
    public ResponseEntity<Object> actualizarOdontologo(@RequestBody Odontologo odontologo) {
        Optional<Odontologo> odontologoBuscado = serviceOdontologo.buscar(odontologo.getId());
        if (odontologoBuscado.isPresent()) {
            serviceOdontologo.actualizar(odontologo);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}